# Aura AI 2.0 Bug Report & System Baseline Audit

| ID | Module | Severity | Flaw Description | Impact | Baseline Status |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **BUG-01** | `permissions.py` | **CRITICAL** | Spoken confirmation does not bind to `pending_confirmation_id`; affirmative responses approve arbitrary queued commands. | Replay attacks, unauthorized command execution. | **FIXED IN STAGE 1** |
| **BUG-02** | `command_service.py` | **CRITICAL** | `eval()` / unparsed `subprocess.Popen` execution allows arbitrary shell code injection from LLM output. | Remote/Local code execution vulnerability. | **FIXED IN STAGE 1** |
| **BUG-03** | `speech_service.py` / `tts_service.py` | **HIGH** | Interruption ("Stop speaking") cancels frontend synthesis but leaves backend audio threads playing in background. | Audio queue desynchronization, audio overlapping. | **FIXED IN STAGE 1** |
| **BUG-04** | `nlp_service.py` | **HIGH** | Static regex-only fallback used when OpenAI API key is missing; no context history maintained across conversational turns. | Context loss in follow-up queries ("Give me an example"). | **PENDING STAGE 2** |
| **BUG-05** | `screenshot_service.py` | **MEDIUM** | Returns timestamped file paths (e.g., `scr_173000.png`) directly in speech response without human-readable directory details or open offers. | Poor UX, uninformative speech feedback. | **PENDING STAGE 3** |
| **BUG-06** | `reminder_service.py` | **MEDIUM** | Reminders scheduled using local `time.sleep()` in volatile memory rather than persistent database-backed background scheduler. | Scheduled tasks lost on application restart. | **PENDING STAGE 5** |
| **BUG-07** | `file_service.py` | **MEDIUM** | Hardcoded scanning path (`C:\Users\Default`); fails on missing directories without error handling. | Directory access crashes, missing file search capability. | **PENDING STAGE 3** |
| **BUG-08** | Frontend `api.ts` | **LOW** | Hardcoded fallback endpoints ignore environment variable configuration (`VITE_API_BASE_URL`). | Deployment failures across non-standard ports. | **FIXED IN STAGE 1** |
