import uuid
import time
from typing import Dict, Optional, Any
from pydantic import BaseModel

class PendingConfirmation(BaseModel):
    id: str
    action_type: str
    target: str
    created_at: float
    ttl: float = 60.0  # Expire after 60 seconds
    parameters: Dict[str, Any]

class Grant(BaseModel):
    action_type: str
    target: str
    granted_at: float
    expires_at: Optional[float] = None

class PermissionManager:
    def __init__(self):
        self._pending: Dict[str, PendingConfirmation] = {}
        self._grants: Dict[str, Grant] = {}

    def create_confirmation_request(self, action_type: str, target: str, parameters: Dict[str, Any] = None) -> PendingConfirmation:
        conf_id = str(uuid.uuid4())
        conf = PendingConfirmation(
            id=conf_id,
            action_type=action_type,
            target=target,
            created_at=time.time(),
            parameters=parameters or {}
        )
        self._pending[conf_id] = conf
        return conf

    def verify_and_grant(self, confirmation_id: str, approved: bool) -> bool:
        if confirmation_id not in self._pending:
            return False
        
        conf = self._pending.pop(confirmation_id)
        if time.time() - conf.created_at > conf.ttl:
            return False  # Expired
        
        if approved:
            grant_key = f"{conf.action_type}:{conf.target}"
            self._grants[grant_key] = Grant(
                action_type=conf.action_type,
                target=conf.target,
                granted_at=time.time()
            )
            return True
        return False

    def is_granted(self, action_type: str, target: str) -> bool:
        grant_key = f"{action_type}:{target}"
        grant = self._grants.get(grant_key)
        if not grant:
            return False
        if grant.expires_at and time.time() > grant.expires_at:
            del self._grants[grant_key]
            return False
        return True

    def revoke_grant(self, action_type: str, target: str) -> bool:
        grant_key = f"{action_type}:{target}"
        if grant_key in self._grants:
            del self._grants[grant_key]
            return True
        return False

permission_manager = PermissionManager()
