import os
from pydantic_settings import BaseSettings
from pydantic import ConfigDict

class Settings(BaseSettings):
    APP_NAME: str = "Aura AI Assistant"
    VERSION: str = "2.0.0"
    API_V1_STR: str = "/api/v1"
    
    # Provider Settings
    OPENAI_API_KEY: str = os.getenv("OPENAI_API_KEY", "")
    OPENAI_MODEL: str = "gpt-4o"
    
    # Storage Settings
    DATABASE_URL: str = "sqlite:///./aura_ai.db"
    SCREENSHOT_DIR: str = os.path.join(os.path.expanduser("~"), "Pictures", "Aura", "Screenshots")
    RESEARCH_EXPORT_DIR: str = os.path.join(os.path.expanduser("~"), "Documents", "Aura", "Research")
    
    # Security
    CONFIRMATION_TTL_SECONDS: float = 60.0
    
    model_config = ConfigDict(env_file=".env", extra="ignore")

settings = Settings()
os.makedirs(settings.SCREENSHOT_DIR, exist_ok=True)
os.makedirs(settings.RESEARCH_EXPORT_DIR, exist_ok=True)
